package csci1010.basseyassign4;

/**
 *CSCI 1010 Programming Assignment 4
 * This is a program that is designed to simulate the motion of a ball
 * @author Saviour Bassey
 */
public class Ball {

    //Declare private fie
    private double hDist;
    private double vDist;
    private double hSpeed;
    private double vSpeed;

    //Set up initial conditions
    public void initialize(double angle, double velocity, double height) {
        hDist = 0;
        vDist = height;
        hSpeed = velocity * (Math.cos(Math.toRadians(angle)));
        vSpeed = velocity * (Math.sin(Math.toRadians(angle)));

    }
    //Update method to update the ball's position and speed over time 
    public void update(double time) {
        //Correctly update horizontal distance
        hDist = hDist + (hSpeed * time);
        
        //Update vertical speed considering gravity
        double vSpeed1;
        vSpeed1 = vSpeed - (time * 9.8);
        
        //Update vertical distance by averaging the speeds
        vDist = vDist + (((vSpeed + vSpeed1)/2) * time);
        
        //Update vSpeed to the new value
        vSpeed = vSpeed1;
    }
    //Accessor method to get horizontal distance
    public double gethDist() {
        return hDist;
    }
    
    //Accessor method to get vertical distance
    public double getvDist() {
        return vDist;
    }
}
