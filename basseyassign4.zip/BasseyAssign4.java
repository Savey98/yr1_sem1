package csci1010.basseyassign4;

import java.util.Scanner;

/**
 *CSCI 1010 Programming Assignment 4
 * This is the main for the Ball class
 * @author Saviour Bassey
 */
public class BasseyAssign4 {

    public static void main(String[] args) {
        //Welcome message
        System.out.println("Welcome to Saviour's ball simulator: ");
        System.out.println();

        Scanner keyboard = new Scanner(System.in);
       
        //Prompt user for information
        System.out.print("Please enter the angle in degrees: ");
        double angle = keyboard.nextDouble();
        System.out.print("Please enter the initial velocity: ");
        double velocity = keyboard.nextDouble();
        System.out.print("Please enter the initial height: ");
        double height = keyboard.nextDouble();
        System.out.print("Please enter the time interval: ");
        double timeInterval = keyboard.nextDouble();

        //Create and initialize the Ball object
        Ball ball = new Ball();
        ball.initialize(angle, velocity, height);

        //Run the simulation while the ball is above the ground
        while (ball.getvDist() > 0) {
            ball.update(timeInterval);
        }
        
        //Display the total horizontal distance traveled
        System.out.println();
        System.out.println("Distance traveled: " + ball.gethDist() + " meters.");
    }
}
