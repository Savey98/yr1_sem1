package csci1010.basseyassign5;
import java.util.Scanner;
/**
 *CSCI Assignment 5
 * @author Saviour Bassey
 * This is the main class for TennisMatch
 */
public class BasseyAssign5 {

    public static void main(String[] args) {
        System.out.println("Welcome to Saviour Bassey's Tennis match simulator");
        Scanner keyboard = new Scanner(System.in);
        
        String continueSimulation;
        do{
            System.out.print("Please enter the number of sets needed to win a match: ");
            int setsToWin = keyboard.nextInt();
            System.out.print("Please enter the probability of Player 1 winning: ");
            double probPlayer1 = keyboard.nextDouble();
            System.out.print("Please enter the probability of Player 2 winning: ");
            double probPlayer2 = keyboard.nextDouble();
            
            //call on TennisMatch class
            TennisMatch match = new TennisMatch(setsToWin, probPlayer1, probPlayer2);
            match.playMatch();
            
            System.out.println();
            System.out.print("Would you like to run another simulation? (Y/N): ");
            continueSimulation = keyboard.next();
        }while(continueSimulation.equalsIgnoreCase("Y")); 
        
        System.out.println("Thank you for using the Tennis match simulator");
    }
}

