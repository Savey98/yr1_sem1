package csci1010.basseyassign5;

/**
 * CSCI1010 Assignment 5
 * @author Saviour Bassey 
 * This is a program designed to simulate a Tennis Match
 * between two players.
 */
public class TennisMatch {

    //declare private fields
    private int setsToWin;
    private double probPlayer1;
    private double probPlayer2;
    private boolean isPlayer1Serving;
    private int player1Score;
    private int player2Score;
    private int setsPlayer1Won;
    private int setsPlayer2Won;
    private String resultsTracker;

    //TennisMatch constructor
    public TennisMatch(int setsToWin, double probPlayer1, double probPlayer2) {
        this.setsToWin = setsToWin;
        this.probPlayer1 = probPlayer1;
        this.probPlayer2 = probPlayer2;
        this.isPlayer1Serving = true;//Makes server 1 the initial server
        this.player1Score = 0;
        this.player2Score = 0;
        this.setsPlayer1Won = 0;
        this.setsPlayer2Won = 0;
        this.resultsTracker = "";
    }

    /*
    Method to continue to playSet unless requirements are met and display 
    results
    */
    public void playMatch() {
        while(!matchOver()){
            playSet();
        }
        if(setsPlayer1Won > setsPlayer2Won){
            System.out.println("Player 1 wins: " + resultsTracker);
        }else{
            System.out.println("Player 2 wins: " + resultsTracker);
        }

    }

    /*
    Method to continue to playGame unless requirements are met and generate 
    results
    */
    private void playSet() {
        player1Score = 0;
        player2Score = 0;
        while(!setOver()){
            playGame();
        }
        if(player1Score> player2Score){
            setsPlayer1Won++;
        }else{
            setsPlayer2Won++;
        }
        resultsTracker += player1Score + "-" + player2Score + " "; 

    }

    //playGame method to simulate the game
    private void playGame() {
        double winRate;
        winRate = Math.random();//Makes winRate a random number
        if (isPlayer1Serving) {
            if (winRate <= probPlayer1) {
                player1Score++;
            } else {
                player2Score++;
            }
        } else {
            if (winRate <= probPlayer2) {
                player2Score++;
            } else {
                player1Score++;
            }
        }
        isPlayer1Serving = !isPlayer1Serving;//Switches the server after a game
    }

    //Boolean to end a match if requirements are met
    private boolean matchOver() {
        return (setsToWin == setsPlayer1Won) || (setsToWin == setsPlayer2Won);
    }

    //Boolean to end a set if requirements are met
    private boolean setOver(){
        return(player1Score >= 6 || player2Score >= 6) &&
                Math.abs(player1Score - player2Score) >= 2;
    }
}
