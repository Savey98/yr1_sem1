package csci1010.basseylab10;

/**
 *CSCI 1011 Lab 10
 * @author Saviour Bassey
 * This is the Java class for BasseyLab10
 */
public class Line {
    //Declare variables
    private double slope;
    private double intercept;
    
    //Default constructor modified by set method
    public Line(){
        set(0.0,0.0);
    }

    public Line(double slope, double intercept) {
        set(slope, intercept);
    }
    
    /**
     * Construct a string in the format "y = mx + b" where m is the slope and b 
     * is the intercept
     * @return A string representation of the line
     */
    public String toString(){
        String equation;
        if (slope == 0){
            equation = "y =" + intercept;
        }
        else if (intercept == 0){
            equation = "y = " + slope + "x";
        }
        else if (intercept > 0){
            equation = "y = " + slope + "x + " + intercept;
        }
        else{
            equation = "y = " + slope + "x + " + -(intercept);
        }
          
        return equation;
    }
    
    //Two-argument constructor
    public void set(double slope, double intercept){
        this.slope = slope;
        this.intercept = intercept;
    }
    
    //Overloaded method set 
    public void set(Point p1, Point p2){
        slope = Point.getSlope(p1, p2);
        intercept = p1.getyCoordinate() - (slope * p1.getxCoordinate());
        
    }
    
    // Accessor for variable: slope
    public double getSlope() {
        return slope;
    }
    
    //Accessor for variable: getIntercept
    public double getIntercept() {
        return intercept;
    }
    
    //getIntersection method
    public static Point getIntersection(Line line1, Line line2){
        double m1 = line1.getSlope();
        double b1 = line1.getIntercept();
        double m2 = line2.getSlope();
        double b2 = line2.getIntercept();
        double x = (b2 - b1) / (m1 - m2);
        double y = m1 * x + b1;
                
        return new Point(x, y);        
    }
    
    //getDistance method
    public static double getDistance(Point point, Line line){
        double x = point.getxCoordinate();
        double y = point.getyCoordinate();
        double m = line.getSlope();
        double b = line.getIntercept();
        
        return Math.abs((m * x) - y + b) / Math.sqrt(m * m + 1);
    }
}
