package csci1011.basseylab11;

import java.util.Scanner;

/**
 *CSCI 1011 Lab 11
 * @author Saviour Bassey
 * This is a program designed to show the course code and title for a specific
 * class and details of their scores
 */
public class Course {
    //Declare variables
    private String courseCode;
    private String courseTitle;
    private double creditHours;
    private double[] studentScores;

    /**
     * Default Constructor
     *
     * @param courseCode - String - course code
     * @param courseTitle - String - course title
     * @param creditHours - double - credit hours
     * @param numberOfStudents - int - number of students in the course
     */
    public Course(String courseCode, String courseTitle, double creditHours, int numberOfStudents) {
        this.courseCode = courseCode;
        this.courseTitle = courseTitle;
        this.creditHours = creditHours;
        this.studentScores = new double[numberOfStudents];

    }

    //Initialize the readScores method to read scores form the user
    public void readScores() {
        Scanner keyboard = new Scanner(System.in);
        int numberOfStudents = studentScores.length;
        System.out.println("Enter the scores for " + numberOfStudents
                + " students");
        for (int i = 0; i < numberOfStudents; i++) {
            studentScores[i] = keyboard.nextDouble();
        }

    }

    //Initialize the displayInfo method to display certain info the user input
    public void displayInfo() {
        System.out.println(courseCode + ": " + courseTitle + " (" + creditHours
                + " credit hours)");
        System.out.println("Class size: " + studentScores.length);
        System.out.print("Scores: ");
        //for(int i = 0; i < studentScores.length; i++){
        //  System.out.println(studentScores[i] + " ");
        //}//Just another way
        for (double score : studentScores) {
            System.out.print(score + " ");
        }
        System.out.println();
    }

    //getSum method to get the sum of the scores input
    private double getSum() {
        double sum = 0;
        for (double score : studentScores) {
            sum += score;
        }
        return sum;
    }

    /**
     * calculate the average student score
     *
     * @return double - average of the students scores
     */
    public double getAverage() {
        double sum = getSum();
        double numStudents = studentScores.length;
        return sum / numStudents;
    }

    //getMax method to get the max score from the scores input by the user
    public double getMax() {
        double max = studentScores[0];
        for (int i = 1; i < studentScores.length; i++) {
            if (studentScores[i] > max) {
                max = studentScores[i];
            }
        }
        return max;
    }

    /**
     * Determine the lowest student score
     *
     * @return - double - lowest score
     */
    public double getMin() {
        double min = studentScores[0];
        for (int i = 1; i < studentScores.length; i++) {
            if (studentScores[i] < min) {
                min = studentScores[i];
            }
        }
        return min;
    }
}


