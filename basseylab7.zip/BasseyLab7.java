package csci1011.basseylab7;
import java.util.Scanner;

/**
 *
 * @author Saviour Bassey
 * CSCI 1011 Lab 7
 * This is a program that compiles information about movies like the title, 
 * and the release year
 */
public class BasseyLab7 {

    public static void main(String[] args) {
        Movie movie = new Movie();
        movie.readInput();
        movie.writeOutput();
        System.out.println();
        
        //mutate the title
        System.out.println("Enter a new title: ");
        Scanner keyboard = new Scanner(System.in);
        String title = keyboard.nextLine();
        String director = movie.getDirector();
        int year = movie.getYear();
        
        //Set only the title - keep the year and the director
        movie.setMovie(title, director, year);
        movie.writeOutput();
    }
}
