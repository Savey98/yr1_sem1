package csci1011.basseylab7;

import java.util.Scanner;

/**
 *
 * @author Saviour Bassey
 * CSCI 1011 Lab 7
 * This is the Java class of BasseyLab7:)
 */
public class Movie {
    //declare the public/private instance variables
    private String title;
    private String director;
    private int year;

    public void readInput() {
        //get user input 
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter the title of the movie: ");
        String title = keyboard.nextLine();
        System.out.println("Enter the director of the movie: ");
        String director = keyboard.nextLine();
        System.out.println("Enter the year the movie as released: ");
        int year = keyboard.nextInt();
        setMovie(title, director, year);

    }

    public void writeOutput() {
        //display the movie  
        System.out.println(title + " dir. " + director + "(" + year + ")");
    }

    /**
     * Sets the Movie class properties
     *
     * @param title
     * @param director
     * @param year
     */
    public void setMovie(String title, String director, int year) {
        this.title = title;
        this.director = director;
        this.year = year;
    }

    /*
    *Gets the title of the movie
    *@return the title of the movie : String
    */
    public String getTitle() {
        return title;
    }

    /*
    *Gets the director of the movie
    *@return the director of the movie : String
     */
    public String getDirector() {
        return director;
    }

    /*
    *Gets the year the movie was released
    *@return the year the movie was released : int
     */
    public int getYear() {
        return year;
    }

}
