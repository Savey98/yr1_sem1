package csci1010.basseylab8;

/**CSCI 1011 Lab8
 * This is the main of Customer.java
 *
 * @author Saviour Bassey
 */
public class BasseyLab8 {

    public static void main(String[] args) {
        //Call the customer classes
        Customer customer1 = new Customer();
        customer1.readInput();
        customer1.writeOutput();
        System.out.println();

        Customer customer2 = new Customer();
        customer2.readInput();
        customer2.writeOutput();

        //Testing using == method
        System.out.println();
        System.out.println("Testing using == method");
        if (customer1 == customer2) {
            System.out.println("Customer1 equal to Customer2 using the == operator");
        } else {
            System.out.println("Customer1 is not equal to Customer2 using the == operator");
        }

        //Testing using equals method
        System.out.println();
        System.out.println("Testing using equals method");
        if (customer1.equals(customer2)) {
            System.out.println("Customer1 is equal to Customer2 using the equals method");
        } else {
            System.out.println("Customer1 is not equals to Customer2 using the equals method");
        }

        System.out.println();
        customer1 = customer2;
        //Testing using == method after using = operator
        System.out.println("Testing using == method after using = operator");
        if (customer1 == customer2) {
            System.out.println("Customer1 equal to Customer2 using the == operator");
        } else {
            System.out.println("Customer1 is not equal to Customer2 using the == operator");
        }

        //Testing after setting email
        System.out.println();
        System.out.println("Test after setting email");
        customer1.setEmail("nobody@nowhere.com");
        customer1.writeOutput();
    }
}
