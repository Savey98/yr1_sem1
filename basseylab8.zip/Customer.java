package csci1010.basseylab8;
import java.util.Scanner;
/**CSCI 1011 Lab8
 * This is a program designed to store a customer's details privately and test 
 * the outcomes with different methods.
 * @author Saviour Bassey
 */
public class Customer {
    //declare methods
    private String firstName;
    private String lastName;
    private String email;

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    public void readInput(){
        //Get input
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter the customer first name:");
        firstName = keyboard.nextLine();
        System.out.println("Enter the customer last name:");
        lastName = keyboard.nextLine();
        System.out.println("Enter the customer email address:");
        email = keyboard.nextLine();
        System.out.println();
    }
    
    public void writeOutput(){
        //Write output
        System.out.println("First Name: " + firstName);
        System.out.println("Last Name: " + lastName);
        System.out.println("Email: " + email);
    }
    private boolean hasSameNameAs(Customer targetCustomer){
        boolean isSame = true;
        
        if(!this.firstName.equals(targetCustomer.firstName)){
        isSame = false;    
        }
        
        if(!this.lastName.equals(targetCustomer.lastName)){
        isSame = false;
        }
                
        return isSame;
    }
    
    private boolean hasSameEmailAs(Customer targetCustomer){
      boolean isSame = true;
      
      if(!this.email.equals(targetCustomer.email)){
      isSame = false;    
      }
      
      return isSame;
    }
    
    public boolean equals(Customer targetCustomer){
        boolean isSame = true;
        
        if(!this.hasSameNameAs(targetCustomer)){
        isSame = false;    
        }
        
        if(!this.hasSameEmailAs(targetCustomer)){
        isSame = false;    
        }
            
        return isSame;
    }
}
