package csci1011.basseylab9;

/**
 *This is the main for the program
 * @author Saviour Bassey
 */
public class BasseyLab9 {

    public static void main(String[] args) {
        //Methods for getNumPoints and Constructors
        testGetNumPoints();
        
        testConstructors();
        
        testGetNumPoints();
        
        //testing getslope
        System.out.println("Testing getSlope method");
        Point p3 = new Point(2, 1);
        Point p4 = new Point(4, 2);
        double slope = Point.getSlope(p3, p4);
        System.out.println("The slope of the line from " + p3.toString() + 
                " to " + p4.toString()+ " is " + slope);
        System.out.println();
        
        //Testing getDistance
        System.out.println("Testing getDistance method");
        Point p5 = new Point(0, 0);
        Point p6 = new Point(3,4);
        double distance = Point.getDistance(p5, p6);
        System.out.println("The distance of the line " + p5.toString() + " to " + 
                p6.toString() + " is " + distance);
        
        
    }
    //End of the main
    //Tests shortened to methods
    private static void testGetNumPoints(){
        int numPoints = Point.getNumPoints();
        System.out.println("Testing getNumPoints method ");
        System.out.println("The number of points created is " + numPoints);
        System.out.println();
    }
    
    private static void testConstructors(){
        System.out.println("Testing the default constructor");
        Point p1 = new Point();
        System.out.println("The point is " + p1.toString());
        System.out.println();
        
        System.out.println("Testing the two-argument constructor");
        Point p2 = new Point(3.5, 8.1);
        System.out.println("The point is " + p2.toString());
        System.out.println();
    }
}
