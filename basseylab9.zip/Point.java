package csci1011.basseylab9;

/**
 * CSCI 1011 Lab 9 This is a program is designed to calculate the distance 
 * between points and their slope
 * @author Saviour Bassey
 */
public class Point {

    //declare variables
    private static int numPoints = 0;
    private double xCoordinate;
    private double yCoordinate;

    //Default constructor to set variables to 0
    public Point() {
        //xCoordinate = 0.0;
        //yCoordinate = 0.0;
        initPoint(0.0, 0.0);
    }

    public Point(double x, double y) {
        //xCoordinate = x;
        //yCoordinate = y
        initPoint(x, y);
    }

    //Accessors for variables
    public double getxCoordinate() {
        return xCoordinate;
    }

    public double getyCoordinate() {
        return yCoordinate;
    }

    public static int getNumPoints() {
        return numPoints;
    }

    //Method to construct string from of Point
    public String toString() {
        return "(" + xCoordinate + ", " + yCoordinate + ")";
    }

    //Two-argument constructor 
    private void initPoint(double xCoordinate, double yCoordinate) {
        this.xCoordinate = xCoordinate;
        this.yCoordinate = yCoordinate;
        numPoints++;
    }

    //Calculate slope
    public static double getSlope(Point p1, Point p2) {
        double xDiff = p1.xCoordinate - p2.xCoordinate;
        double yDiff = p2.yCoordinate - p2.yCoordinate;
        return yDiff / xDiff;
    }

    //Calculate distance
    public static double getDistance(Point p1, Point p2){
        double xDiff = p1.xCoordinate - p2.xCoordinate;
        double yDiff = p1.yCoordinate - p2.yCoordinate;
        return Math.sqrt(xDiff * xDiff + yDiff * yDiff);
    }
    
}
