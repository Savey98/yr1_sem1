package Enterprises;

/**
 *
 * @author Saviour Bassey
 */
public class Customer {
    
}
