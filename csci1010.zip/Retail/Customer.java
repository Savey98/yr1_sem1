package Retail;

/**
 *
 * @author Saviour Bassey
 */
public class Customer {
    
}
