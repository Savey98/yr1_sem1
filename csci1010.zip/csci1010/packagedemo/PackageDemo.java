package csci1010.packagedemo;
//import Retail.Customer;
//import Retail.Items;

import Retail.Customer;
import Enterprises.Customer;

/**
 *
 * @author Saviour Bassey
 */
public class PackageDemo {

    public static void main(String[] args) {
        Customer rc = new Customer();
        System.out.println("Hello World!");
        Items i1 = new Items();
        Customer ec = new Customer();
        System.out.println("ec = " + ec.toString());
    }
}
